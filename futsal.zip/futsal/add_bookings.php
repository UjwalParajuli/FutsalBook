<?php
include 'inc/db.php';

date_default_timezone_set("Asia/Kathmandu");
$today_date = date("Y-m-d H:i:s");
$time_table_id = (int)$_POST['time_table_id'];
$futsal_id = (int)$_POST['futsal_id'];
$user_id = (int)$_POST['user_id'];
$selected_date = strtotime($_POST['selected_date']);
$_selected_date = date('Y-m-d', $selected_date);
$amount = (int)$_POST['amount'];

$sql = "insert into futsal_bookings (user_id, futsal_id, time_table_id, booked_date, booked_on, paid_amount) values ($user_id, $futsal_id, $time_table_id, '$_selected_date', '$today_date', $amount)";
$result = mysqli_query($conn, $sql);
if ($result) {
	echo "success";
}
else{
    echo "error";
}

?>