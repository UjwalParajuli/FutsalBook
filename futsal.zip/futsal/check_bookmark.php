<?php
include 'inc/db.php';

$user_id = (int)$_POST['user_id'];
$futsal_id = (int)$_POST['futsal_id'];

$data = array();

$sql = "select * from saved_futsals where futsal_id = $futsal_id and user_id = $user_id ";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) < 1) {
	echo "not_found";
}
else{
    echo "found";
		
}

?>