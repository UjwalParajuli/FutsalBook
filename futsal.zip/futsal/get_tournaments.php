<?php
include 'inc/db.php';

$data = array();
mysqli_set_charset($conn, 'utf8');
date_default_timezone_set("Asia/Kathmandu");
$today_date = date("Y-m-d");
$sql = "select futsal_details.futsal_name, futsal_details.location, tournaments.tournament_id, tournaments.futsal_id, tournaments.tournament_name, tournaments.description, tournaments.start_date, tournaments.end_date, tournaments.registration_deadline_date, tournaments.registration_fee, tournaments.first_prize, tournaments.second_prize, tournaments.organized_by, tournaments.organizer_contact, tournaments.banner from futsal_details inner join tournaments on futsal_details.futsal_id = tournaments.futsal_id where DATE(tournaments.start_date) >= '$today_date' ";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) <= 0) {
	echo "not_found";
}
else{
    while($row = mysqli_fetch_assoc($result)) {
        $data[] = $row;
	}
    echo json_encode($data);
}

?>