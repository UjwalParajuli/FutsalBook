<?php
include 'inc/db.php';

//$user_id = (int)$_POST['user_id'];
$user_id = 3;
date_default_timezone_set("Asia/Kathmandu");
$today_date = date("Y-m-d");
$current_time = date("H:i:s");
$data = array();

$sql = "select futsal_details.futsal_name, futsal_details.location, futsal_details.image, time_table.start_time, time_table.end_time, futsal_bookings.booked_date from futsal_bookings inner join time_table on time_table.time_table_id = futsal_bookings.time_table_id inner join futsal_details on futsal_details.futsal_id = futsal_bookings.futsal_id where futsal_bookings.user_id = $user_id and DATE(futsal_bookings.booked_date) >= '$today_date' and TIME(time_table.start_time) <= '$current_time'  ";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) < 1) {
	echo "not_found";
}
else{
    while($row = mysqli_fetch_assoc($result)) {
        $data[] = $row;
	}
    echo json_encode($data);
		
}

?>