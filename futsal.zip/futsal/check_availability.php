<?php
include 'inc/db.php';

$time_table_id = (int)$_POST['time_table_id'];
$futsal_id = (int)$_POST['futsal_id'];
$selected_date = strtotime($_POST['selected_date']);
$_selected_date = date('Y-m-d', $selected_date);

$data = array();

$sql = "select * from futsal_bookings where futsal_id = $futsal_id and time_table_id = $time_table_id and DATE(booked_date) = '$_selected_date' ";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) <= 0) {
	echo "not_found";
}
else{
    echo "found";
		
}

?>