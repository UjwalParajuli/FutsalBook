<?php
include 'inc/db.php';

$user_id = (int)$_POST['user_id'];
$data = array();

$sql = "select futsal_details.futsal_id, futsal_details.futsal_name, futsal_details.location, futsal_details.description, futsal_details.phone, futsal_details.price_per_hour, futsal_details.image from saved_futsals inner join futsal_details on futsal_details.futsal_id = saved_futsals.futsal_id where saved_futsals.user_id = $user_id ";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) < 1) {
	echo "not_found";
}
else{
    while($row = mysqli_fetch_assoc($result)) {
        $data[] = $row;
	}
    echo json_encode($data);
		
}

?>