<?php
include 'inc/db.php';

$email = strip_tags(htmlspecialchars($_POST['email']));
$password = $_POST['password'];

$json_array = array();

$sql = "select * from users where email = '$email'";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) < 1) {
	echo "first_db_error";
}
else{
    if ($row = mysqli_fetch_array($result)) {
		if ($email == $row["email"] && password_verify("$password", $row["password"])) {
			$json_array = $row;
			echo json_encode($json_array);	
		}

		elseif ($email != $row["email"] || password_verify("$password", $row["password"])) {

			echo "credential_error";
		}

		elseif ($email == $row["email"] || (!password_verify("$password", $row["password"]))) {
			echo "credential_error";
		}

		elseif ($email != $row["email"] || (!password_verify("$password", $row["password"]))) {
			echo "credential_error";
		}

					
	}
	else{
		echo "second_db_error";
	}
}

?>