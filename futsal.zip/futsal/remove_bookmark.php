<?php
include 'inc/db.php';

$user_id = (int)$_POST['user_id'];
$futsal_id = (int)$_POST['futsal_id'];

$sql = "delete from saved_futsals where user_id = $user_id and futsal_id = $futsal_id ";
$result = mysqli_query($conn, $sql);
if ($result) {
	echo "success";
}
else{
    echo "not_success";
}

?>