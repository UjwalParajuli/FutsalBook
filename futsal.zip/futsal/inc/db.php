<?php
$servername = "localhost";
$dbname = "rajkumar_futsal_book";
$uname = "rajkumar_futsal_admin";
$pass = "54j[Zhx1v;VTY0";
$conn = mysqli_connect($servername, $uname, $pass, $dbname);
if (!$conn) {
    die("Connection failed!");
}
?>