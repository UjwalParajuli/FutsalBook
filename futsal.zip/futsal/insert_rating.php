<?php
include 'inc/db.php';

$futsal_id = (int)$_POST['futsal_id'];
$user_id = (int)$_POST['user_id'];
$rating = floatval($_POST['rating']);
date_default_timezone_set("Asia/Kathmandu");
$today_date = date("Y-m-d H:i:s");

$sql = "select * from ratings where futsal_id = $futsal_id and user_id = $user_id ";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
	$qry = "delete from ratings where futsal_id = $futsal_id and user_id = $user_id ";
    $result2 = mysqli_query($conn, $qry);
    if($result2){
        $qry2 = "insert into ratings (user_id, futsal_id, rating, given_date) values ($user_id, $futsal_id, $rating, '$today_date') ";
        $result3 = mysqli_query($conn, $qry2);
        if($result3){
            echo 'success';
        }
        else{
            echo 'insert_error';
        }
    }
    else{
        echo 'delete_error';
    }
}
else{
    $qry3 = "insert into ratings (user_id, futsal_id, rating, given_date) values ($user_id, $futsal_id, $rating, '$today_date') ";
    $result4 = mysqli_query($conn, $qry3);
    if($result4){
        echo 'success';
    }
    else{
        echo 'insert_error';
    }
		
}

?>