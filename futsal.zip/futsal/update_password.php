<?php
include 'inc/db.php';

$new_password = $_POST['new_password'];
$user_id = (int)$_POST['user_id'];

$hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
$qry = "update users set password = '$hashed_password' where user_id = $user_id ";
        
$result = mysqli_query($conn, $qry);
if(!$result){
    echo "dbError";
}
else{
    
    echo "success";
    
}
  
?>