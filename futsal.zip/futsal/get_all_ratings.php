<?php
include 'inc/db.php';

$futsal_id = (int)$_POST['futsal_id'];
$data = array();

$sql = "select users.full_name, ratings.rating from ratings inner join users on users.user_id = ratings.user_id where ratings.futsal_id = $futsal_id ";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) < 1) {
	echo "not_found";
}
else{
    while($row = mysqli_fetch_assoc($result)) {
        $data[] = $row;
	}
    echo json_encode($data);
		
}

?>