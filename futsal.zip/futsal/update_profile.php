<?php
include 'inc/db.php';

$full_name = $_POST['full_name'];
$phone = $_POST['phone'];
$new_email = strip_tags(htmlspecialchars($_POST['new_email']));
$old_email = strip_tags(htmlspecialchars($_POST['old_email']));
$user_id = (int)$_POST['user_id'];

if($old_email != $new_email){
    $sql = "select * from users where (email = '$new_email');";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) {
        echo "email_taken";
    }
    else{
        $qry = "update users set full_name = '$full_name', email = '$new_email', phone = '$phone' where user_id = $user_id ";    
        $result = mysqli_query($conn, $qry);
        if(!$result){
            echo "dbError";
        }
        else{
            echo "success";
        }
    }

}
else{
    $qry = "update users set full_name = '$full_name', phone = '$phone' where user_id = $user_id ";    
    $result = mysqli_query($conn, $qry);
    if(!$result){
        echo "dbError";
    }
    else{
        echo "success";
    }
}
  
?>