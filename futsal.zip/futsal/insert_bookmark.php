<?php
include 'inc/db.php';

$user_id = (int)$_POST['user_id'];
$futsal_id = (int)$_POST['futsal_id'];

$sql = "insert into saved_futsals (user_id, futsal_id) values ($user_id, $futsal_id)";
$result = mysqli_query($conn, $sql);
if ($result) {
	echo "success";
}
else{
    echo "not_success";
}

?>