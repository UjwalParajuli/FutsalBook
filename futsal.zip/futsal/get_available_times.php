<?php
include 'inc/db.php';

$futsal_id = (int)$_POST['futsal_id'];
date_default_timezone_set("Asia/Kathmandu");
$today_date = date("Y-m-d");
$data = array();

$sql = "select * from time_table where not exists (select * from futsal_bookings where time_table.time_table_id = futsal_bookings.time_table_id and futsal_bookings.futsal_id = $futsal_id and DATE(futsal_bookings.booked_date) = '$today_date')";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) < 1) {
	echo "not_found";
}
else{
    while($row = mysqli_fetch_assoc($result)) {
        $data[] = $row;
	}
    echo json_encode($data);
		
}

?>